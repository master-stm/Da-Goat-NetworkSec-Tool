# PacketInspector/PacketSniffer by Team 12

### Packet sniffing in python

### Installation
To install dependencies and libraries for this program you can use scripts:  
 • for unix systems - install_dependencies.sh;  
 • for windows - install_dependencies.bat.  

### About
You can start PacketInspector with -h argument to see all opportunities. 


### Examples
You can start sniffer with "-I -H -S -s test" arguments to use interactive mode, print more information about packets and save them into file test.pcap.  
At start you can choose interface to sniff on and protocol to filter packets.  
After you will see packets and after sniffing packets will be available in file with unique name 
You can open pcap file with Wireshark.