from colorama import Fore, Style
from prettytable import PrettyTable

def print_color(text, color=None) -> None:
  '''
  Print color text
  '''
  if color:
    color_obj = getattr(Fore, color.upper(), None)
    if color_obj:
      print(color_obj + text + Style.RESET_ALL)
      return
  print(text)  
  
def print_logo() -> None:
  print(Fore.GREEN + 
'                           .-.          \n' 
'                          {{#}}         \n' 
'          {}               8@8          \n'
'        .::::.             888          \n'
'    @\/\/W\/\/W\//@        8@8          \n'
'     \/\/^\/\/^\//     _   )8(    _     \n'
'      \_O_{}_O_/     (@)__/8@8\__(@)    \n'
' ____________________ `~.-=):(=-.~`     \n' 
'|<><><>  |  |  <><><>|     |.|          \n'
'|<>      |  |      <>|     |S|          \n'
'|<>      |  |      <>|     |.|          \n'
'|<>   .--------.   <>|     |.|          \n'
'|     |   ()   |     |     |P|          \n'
'|_____| (O\/O) |_____|     |.|          \n'
'|     \   /\   /     |     |.|          \n'
'|------\  \/  /------|     |U|          \n'
'|       `.__.`       |     |.|          \n'
'|        |  |        |     |.|          \n'
':        |  |        :     |N|          \n'
' \       |  |       /      |.|          \n'
'  \<>    |  |    <>/       |.|          \n'
'   \<>   |  |   <>/        |K|          \n' 
'    `\<> |  | <>/`         |.|          \n'
'      `-.|__|.-`           \ /          \n'
'                            v           \n'
        + Style.RESET_ALL)
 
def print_table_with_interfaces(interfaces) -> None:
  '''
  Print table of interfaces
  '''
  table = PrettyTable()
  table.field_names = ['#', 'Interface', 'Ip']
  for i, interface in enumerate(interfaces):
    table.add_row([i+1, interface['name'], interface['ip']])
  print(table)
 