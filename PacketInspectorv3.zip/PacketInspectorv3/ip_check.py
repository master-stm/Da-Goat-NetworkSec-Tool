# from scapy.all import *
# import ipaddress

# ports = [25,80,53,443,445,8080,8443]

# def SynScan(host):
#     ans,unans = (
#         IP(dst=host)/TCP(sport=333,dport=ports,flags="S"),timeout=2,verbose=0)
#     print("Open ports at $s: " % host)
#     for (s,r,) in ans:
#         if s[TCP].dport == r[TCP].sport and r[TCP].flags == "SA":
#             print(s[TCP].dport)
from scapy.all import *
import ipaddress
from scapy.layers.inet import TCP  # More specific import
from scapy.layers.inet import IP
ports = [25, 80, 53, 443, 445, 8080, 8443]

def SynScan(host):
    ans, unans = sr(IP(dst=host) / TCP(sport=RandShort(), dport=ports, flags="S"), timeout=2, verbose=0)
    print("Open ports at", host)  # Use comma for string formatting
    for (s, r) in ans:
        if s[TCP].dport == r[TCP].sport and r[TCP].flags == "SA":
            print(s[TCP].dport)
